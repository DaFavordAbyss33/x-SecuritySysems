---
name: Need help
about: Stuck some where during setup or using a command?
title: 'Why is _____ happening?'
labels: ''
assignees: ''

---

What's the problem you are having while you are using C-REAL?

Have you checked the errors in the console?
Yes or no
